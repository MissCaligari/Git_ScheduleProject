Tic Tac Toe by Seth A. Robinson

codedojo.com

Requires Unity 4.3+, open Assets/main.unity to play